import pygame

pygame.init()

jump_sound = pygame.mixer.Sound('Sounds/Rrr.wav')
fall_sound = pygame.mixer.Sound('Sounds/Bdish.wav')
lose_sound = pygame.mixer.Sound('Sounds/loss.wav')
heart_plus_sound = pygame.mixer.Sound('Sounds/hp+.wav')
button_sound = pygame.mixer.Sound('Sounds/button.wav')
bullet_sound = pygame.mixer.Sound('Sounds/shot.wav')