import pygame

width, height = 640, 480

pygame.init()
clock = pygame.time.Clock()
screen = pygame.display.set_mode((width,height))
surface = pygame.display.set_mode((width,height), pygame.SRCALPHA)

while True:
    msElapsed = clock.tick(100)
    screen.fill((255,255,0))
    pygame.draw.circle(surface,(30,224,33,128),(250,100),10)
    screen.blit(surface, (0,0))
    pygame.display.update()

    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            exit()