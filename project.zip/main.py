from game import *
import pygame

pygame.init()

new_game = Game()
new_game.start()
pygame.quit()
pefile