import pygame

pygame.init()

jump_sound = pygame.mixer.Sound('resources/Sounds/Rrr.wav')
fall_sound = pygame.mixer.Sound('resources/Sounds/Bdish.wav')
lose_sound = pygame.mixer.Sound('resources/Sounds/loss.wav')
heart_plus_sound = pygame.mixer.Sound('resources/Sounds/hp+.wav')
button_sound = pygame.mixer.Sound('resources/Sounds/button.wav')
bullet_sound = pygame.mixer.Sound('resources/Sounds/shot.wav')